<?php
echo file_put_contents("data.txt");
?>