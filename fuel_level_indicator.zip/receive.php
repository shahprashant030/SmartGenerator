<?php
$string="dist".$_GET["dist"];
file_put_contents("data.txt",$string);
?>